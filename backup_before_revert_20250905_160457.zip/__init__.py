# minimal init
