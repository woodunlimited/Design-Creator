import sys, runpy, pathlib
root = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / "src"))
target = root / "tools" / "preview_cyl_taper.py"
sys.argv[0] = str(target)
runpy.run_path(str(target), run_name="__main__")