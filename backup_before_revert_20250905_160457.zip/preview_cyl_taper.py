import os, json, io, pathlib
from PIL import Image, ImageDraw
try:
    import cairosvg
except Exception:
    cairosvg = None

from mockup.warp import apply_cyl_taper

def load_json(p):
    with open(p, "r", encoding="utf-8-sig") as f:
        return json.load(f)

def fit_contain(w, h, box_w, box_h):
    s = min(box_w / w, box_h / h)
    return max(1, int(round(w*s))), max(1, int(round(h*s)))

def rasterize_design(dpath, out_w, out_h):
    ext = pathlib.Path(dpath).suffix.lower()
    if ext == ".svg":
        if cairosvg is None:
            raise RuntimeError("cairosvg not installed")
        png_bytes = cairosvg.svg2png(url=dpath, output_width=out_w, output_height=out_h)
        im = Image.open(io.BytesIO(png_bytes)).convert("RGBA")
        return im
    return Image.open(dpath).convert("RGBA")

def make_overlay(design_rgba, stainless_path, knockout_white=245):
    # tile/scale stainless to overlay size, then mask by design alpha or non-white
    W,H = design_rgba.size
    steel = Image.open(stainless_path).convert("RGB").resize((W,H), Image.LANCZOS)

    # Build mask: prefer alpha; also knock out near-white pixels if requested
    alpha = design_rgba.split()[-1]
    if knockout_white is not None:
        import numpy as np
        arr = np.array(design_rgba)
        non_white = ~((arr[...,0] >= knockout_white) & (arr[...,1] >= knockout_white) & (arr[...,2] >= knockout_white))
        m = (non_white * 255).astype("uint8")
        alpha = Image.fromarray(m, "L")

    ov = Image.new("RGBA", (W,H))
    ov.paste(steel, (0,0))
    ov.putalpha(alpha)
    return ov

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-dir", required=True)
    ap.add_argument("--design", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--strength", type=float, default=0.04)
    ap.add_argument("--taper", type=float, default=0.03)
    ap.add_argument("--skew", type=float, default=0.00)
    ap.add_argument("--stainless", default=r"C:\Users\Louie\Design Creator\textures\stainless_custom.jpg")
    args = ap.parse_args()

    spec_path = os.path.join(args.base_dir, "print_areas.json")
    spec = load_json(spec_path)
    base_img = Image.open(os.path.join(args.base_dir, spec["image"])).convert("RGBA")
    W, H = base_img.size

    area = spec["areas"][0]
    x = int(round(area["rect"]["x"] * W))
    y = int(round(area["rect"]["y"] * H))
    w = int(round(area["rect"]["w"] * W))
    h = int(round(area["rect"]["h"] * H))

    pad = float(area.get("padding_ratio", 0.0))
    bx = x + int(round(w*pad))
    by = y + int(round(h*pad))
    bw = max(1, w - 2*int(round(w*pad)))
    bh = max(1, h - 2*int(round(h*pad)))

    tmp = rasterize_design(args.design, bw, bh)
    tw, th = tmp.size
    s = min(bw / tw, bh / th)
    fw, fh = max(1, int(round(tw*s))), max(1, int(round(th*s)))
    design_rgba = tmp.resize((fw, fh), Image.LANCZOS)

    knockout = None
    if "stainless" in area and isinstance(area["stainless"], dict):
        knockout = area["stainless"].get("knockout_white", 245)
    overlay = make_overlay(design_rgba, args.stainless, knockout_white=knockout)

    overlay = apply_cyl_taper(overlay, strength=args.strength, taper=args.taper, skew=args.skew)

    ox = bx + (bw - overlay.width)//2
    oy = by + (bh - overlay.height)//2

    comp = base_img.copy()
    comp.alpha_composite(overlay, dest=(ox, oy))

    dr = ImageDraw.Draw(comp)
    t = max(2, int(min(W,H)*0.0025))
    dr.rectangle([x,y,x+w,y+h], outline=(255,0,0,255), width=t)
    dr.rectangle([bx,by,bx+bw,by+bh], outline=(0,200,0,255), width=t)

    os.makedirs(args.out, exist_ok=True)
    outf = os.path.join(args.out, "PREVIEW_cyl_taper.jpg")
    comp.convert("RGB").save(outf, quality=90)
    print("Wrote", outf)

if __name__ == "__main__":
    main()