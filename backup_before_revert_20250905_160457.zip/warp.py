from PIL import Image

def _map_uv(u, v, strength=0.04, taper=0.03, skew=0.0):
    # u,v in [0..1]
    x = 2.0*u - 1.0
    y = v
    k = -float(strength) * (1.0 + float(taper) * (y - 0.5) * 2.0)  # negative => compress edges
    x += float(skew) * (y - 0.5) * 2.0                              # camera skew
    x_src = x * (1.0 + k * (x*x))                                   # cubic barrel along X
    x_src = max(-1.0, min(1.0, x_src))
    u_src = (x_src + 1.0) / 2.0
    v_src = y
    return u_src, v_src

def _mesh_for_barrel(w, h, strength, taper, skew, grid=36):
    # Build PIL MESH mapping (list of (box, quad)) that approximates our mapping.
    cols = rows = max(8, int(grid))
    mesh = []
    for j in range(rows):
        v0 = j / rows
        v1 = (j + 1) / rows
        y0 = int(round(v0 * h))
        y1 = int(round(v1 * h))
        for i in range(cols):
            u0 = i / cols
            u1 = (i + 1) / cols
            x0 = int(round(u0 * w))
            x1 = int(round(u1 * w))
            box = (x0, y0, x1, y1)
            qu = []
            for (uu, vv) in ((u0, v0), (u1, v0), (u1, v1), (u0, v1)):
                su, sv = _map_uv(uu, vv, strength, taper, skew)
                qu.extend([su * w, sv * h])
            mesh.append((box, tuple(qu)))
    return mesh

def apply_cyl_taper(img_rgba, strength=0.04, taper=0.03, skew=0.0):
    """Return new RGBA image warped with cylindrical + taper mapping (X-only)."""
    if img_rgba.mode != "RGBA":
        img_rgba = img_rgba.convert("RGBA")
    w, h = img_rgba.size
    mesh = _mesh_for_barrel(w, h, strength, taper, skew, grid=max(24, int(w/75)))
    return img_rgba.transform((w, h), Image.MESH, mesh, Image.BICUBIC)